# NoX Charge Alert

Native Android app for charging connected/disconnected alerts.

Features:
- Fixed connected/disconnected chimes.
- Reads the LIVE battery percentage when the event happens.
- Optional spoken battery percentage using Android Text-to-Speech.
- Notifications.
- Enable/disable each alert.
- Test buttons.
- Works without internet.

Important:
- The fixed sound is only the chime. The battery percentage is NEVER hard-coded.
  If the phone is at 91%, it says/shows 91%.
- Android 13+ asks for notification permission.
- Some phone manufacturers aggressively restrict background behavior. If alerts
  are unreliable, allow notifications and disable battery optimization for this
  app in the phone's battery/app settings.

Build without a PC:
1. Create a GitHub repository.
2. Upload the contents of this project.
3. Commit to main.
4. Open the Actions tab.
5. Run "Build NoX Charge Alert APK" (it also runs automatically on push).
6. Open the completed workflow run.
7. Download the "NoX-Charge-Alert-debug" artifact.
8. Extract the APK and install it on Android.

This is a debug APK for personal use, not a Play Store release build.
