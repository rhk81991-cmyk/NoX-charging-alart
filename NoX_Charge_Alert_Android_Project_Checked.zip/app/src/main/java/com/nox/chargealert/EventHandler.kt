package com.nox.chargealert

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

object EventHandler {
    const val CHANNEL_ID = "charge_events"

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun handle(
        context: Context,
        event: String,
        percent: Int,
        onFinished: (() -> Unit)? = null
    ) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val enabled = if (event == PowerReceiver.EVENT_CONNECTED) {
            prefs.getBoolean("connected", true)
        } else {
            prefs.getBoolean("disconnected", true)
        }

        if (!enabled) {
            onFinished?.invoke()
            return
        }

        ensureChannel(appContext)

        // Fixed chime: this audio never changes with the battery percentage.
        val soundRes = if (event == PowerReceiver.EVENT_CONNECTED) {
            R.raw.connected
        } else {
            R.raw.disconnected
        }

        var finished = false
        fun finishOnce() {
            if (!finished) {
                finished = true
                onFinished?.invoke()
            }
        }

        val player = MediaPlayer.create(appContext, soundRes)
        if (player != null) {
            player.setOnCompletionListener {
                it.release()
                finishOnce()
            }
            player.setOnErrorListener { mp, _, _ ->
                mp.release()
                finishOnce()
                true
            }
            player.start()
        } else {
            finishOnce()
        }

        val title = if (event == PowerReceiver.EVENT_CONNECTED) {
            "Charging connected"
        } else {
            "Charging disconnected"
        }
        val notification = NotificationCompat.Builder(appContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(title)
            .setContentText("Battery $percent%")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(if (event == PowerReceiver.EVENT_CONNECTED) 101 else 102, notification)

        if (prefs.getBoolean("speak", true)) {
            speakLivePercent(appContext, event, percent)
        }
    }

    @Synchronized
    private fun speakLivePercent(context: Context, event: String, percent: Int) {
        val text = if (event == PowerReceiver.EVENT_CONNECTED) {
            "Charging connected. Battery $percent percent."
        } else {
            "Charging disconnected. Battery $percent percent."
        }

        if (tts == null) {
            ttsReady = false
            tts = TextToSpeech(context) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    ttsReady = true
                    // Speak the first event too; don't silently lose it while TTS initializes.
                    tts?.speak(
                        text,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        "nox_${event}_${System.currentTimeMillis()}"
                    )
                }
            }
            return
        }

        if (ttsReady) {
            tts?.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "nox_${event}_${System.currentTimeMillis()}"
            )
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build()
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Charging events",
                    NotificationManager.IMPORTANCE_HIGH
                )
                channel.description = "NoX charging connected/disconnected alerts"
                // The app plays its own fixed chime, so the notification channel stays silent.
                channel.setSound(null, attrs)
                nm.createNotificationChannel(channel)
            }
        }
    }
}
