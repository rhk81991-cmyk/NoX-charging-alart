package com.nox.chargealert

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager

class PowerReceiver : BroadcastReceiver() {
    companion object {
        const val EVENT_CONNECTED = "connected"
        const val EVENT_DISCONNECTED = "disconnected"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val event = when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> EVENT_CONNECTED
            Intent.ACTION_POWER_DISCONNECTED -> EVENT_DISCONNECTED
            else -> return
        }

        // Keep the receiver alive long enough for the short fixed chime to finish.
        val pendingResult = goAsync()
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilterCompat.batteryChanged()
        )
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0) {
            (level * 100 / scale.coerceAtLeast(1)).coerceIn(0, 100)
        } else {
            0
        }

        EventHandler.handle(
            context.applicationContext,
            event,
            percent,
            onFinished = { pendingResult.finish() }
        )
    }
}

object IntentFilterCompat {
    fun batteryChanged() = android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
}
